# pomodoroX
Simple pomodoro program written in Powershell. You can use this program for time management as well as get yourself up and moving. 

Download the application https://github.com/devendra061/pomodoroX/blob/main/PomodoroX.zip
Unzip the file
Copy the 'image' folder in your C: Drive
Go to the image folder; Drag pomodoroX.exe to the taskbar for a quick access to the program

Run promodorX.exe 
	
Enter the time in minutes you want to work uninterrupted

Once the time is up, the motivational image (image1.jpg) will pop-up to remind you to take break

Input notes on what work you did; All the notes will be archived in c:\image\notes.txt file