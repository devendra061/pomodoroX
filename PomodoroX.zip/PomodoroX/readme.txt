Copy the image folder in your C: Drive
Go to the image folder; Drag pomodorX.exe to the taskbar for the quick access to the program
Run promodorX.exe 
	Enter the time in minutes you want to work uninterrupted
	Once the time is up, the motivational image (image1.jpg) will pop-up to remind you to take break
	Input notes on what work you did
