﻿$mins = 25
$start=$(get-date);$diff=$(get-date)-$start
$total=new-object TimeSpan -argumentList 0,$mins,0
while ($diff -lt $total) {
	write-progress -activity $diff -PercentComplete (($diff.TotalSeconds/$total.TotalSeconds)*100) -Status "Work!"
	sleep 1
	$diff=$(get-date)-$start
}
start c:\image\image1.jpg
$note=Read-Host 'Input your notes'
$date=Get-Date
if($note){
Add-Content c:\image\notes.txt $note
Add-Content c:\image\notes.txt $date
} else {
Write-Warning - Message "No notes left"
}